package com.examples.spring.boot.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootEmployeeWebApp {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootEmployeeWebApp.class, args);
	}
}
