package com.examples.spring.core.bean;

public class AccountService {
	
	public String getMessage()
	{
		return "Hello World from Account Service";
	}

}
