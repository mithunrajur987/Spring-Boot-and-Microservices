package com.examples.spring.core;

public class Greetings {
	
	private String message = "Spring Hello World!";

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
