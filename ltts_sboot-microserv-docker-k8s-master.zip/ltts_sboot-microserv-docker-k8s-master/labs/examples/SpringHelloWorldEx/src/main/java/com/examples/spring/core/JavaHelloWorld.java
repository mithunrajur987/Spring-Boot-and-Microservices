package com.examples.spring.core;

public class JavaHelloWorld {
	
	public static void main(String[] args)
	{
		System.out.println("Hello World!");
	}

}
